A Pen created at CodePen.io. You can find this one at https://codepen.io/Bulletproof-Circle/pen/eXeqqV.

 Hi, I'm just your average pen. Kinda new here, just lookin' for frenz.

UPDATE: My cousin [pen#JoVrdw](http://codepen.io/jakealbaugh/full/JoVrdw) joined CodePen! 